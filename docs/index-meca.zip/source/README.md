# althingi-forecast-2025
Forecasting model and data analysis for the 2025 Icelandic parliamentary elections
